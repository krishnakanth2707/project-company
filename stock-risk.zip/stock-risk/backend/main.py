from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
import yfinance as yf
import os

from data_fetcher import fetch_price_data, fetch_news, get_company_name
from feature_engineering import compute_features
from predictor import predict_risk
from llm_analyzer import analyze_with_llm

app = FastAPI(title="Stock Risk Analyzer")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Indian NSE tickers for dropdown
INDIAN_STOCKS = [
    {"ticker": "HDFCBANK.NS",   "name": "HDFC Bank"},
    {"ticker": "TCS.NS",        "name": "Tata Consultancy Services"},
    {"ticker": "HINDUNILVR.NS", "name": "Hindustan Unilever"},
    {"ticker": "ITC.NS",        "name": "ITC Limited"},
    {"ticker": "NESTLEIND.NS",  "name": "Nestle India"},
    {"ticker": "INFY.NS",       "name": "Infosys"},
    {"ticker": "WIPRO.NS",      "name": "Wipro"},
    {"ticker": "ICICIBANK.NS",  "name": "ICICI Bank"},
    {"ticker": "KOTAKBANK.NS",  "name": "Kotak Mahindra Bank"},
    {"ticker": "SBIN.NS",       "name": "State Bank of India"},
    {"ticker": "RELIANCE.NS",   "name": "Reliance Industries"},
    {"ticker": "MARUTI.NS",     "name": "Maruti Suzuki"},
    {"ticker": "BHARTIARTL.NS", "name": "Bharti Airtel"},
    {"ticker": "ONGC.NS",       "name": "Oil & Natural Gas Corp"},
    {"ticker": "SUNPHARMA.NS",  "name": "Sun Pharmaceutical"},
    {"ticker": "TATASTEEL.NS",  "name": "Tata Steel"},
    {"ticker": "HINDALCO.NS",   "name": "Hindalco Industries"},
    {"ticker": "DRREDDY.NS",    "name": "Dr Reddy's Laboratories"},
    {"ticker": "POWERGRID.NS",  "name": "Power Grid Corp"},
    {"ticker": "NTPC.NS",       "name": "NTPC"},
    {"ticker": "BAJFINANCE.NS", "name": "Bajaj Finance"},
    {"ticker": "ADANIENT.NS",   "name": "Adani Enterprises"},
    {"ticker": "ADANIPORTS.NS", "name": "Adani Ports"},
    {"ticker": "ZOMATO.NS",     "name": "Zomato"},
    {"ticker": "TATAPOWER.NS",  "name": "Tata Power"},
    {"ticker": "YESBANK.NS",    "name": "Yes Bank"},
    {"ticker": "SUZLON.NS",     "name": "Suzlon Energy"},
    {"ticker": "IDEA.NS",       "name": "Vodafone Idea"},
    {"ticker": "RPOWER.NS",     "name": "Reliance Power"},
    {"ticker": "PNB.NS",        "name": "Punjab National Bank"},
]

PERIODS = [
    {"value": "1M", "label": "1 Month"},
    {"value": "3M", "label": "3 Months"},
    {"value": "6M", "label": "6 Months"},
    {"value": "1Y", "label": "1 Year"},
    {"value": "3Y", "label": "3 Years"},
    {"value": "5Y", "label": "5 Years"},
]

class AnalyzeRequest(BaseModel):
    ticker: str
    period: str = "1Y"

@app.get("/stocks")
def get_stocks():
    return {"stocks": INDIAN_STOCKS}

@app.get("/periods")
def get_periods():
    return {"periods": PERIODS}

@app.get("/download-dataset")
def download_dataset():
    path = "models/training_dataset.csv"
    if not os.path.exists(path):
        raise HTTPException(404, "Dataset not found. Train the model first.")
    return FileResponse(
        path,
        media_type="text/csv",
        filename="indian_stocks_training_dataset.csv"
    )

@app.post("/analyze")
async def analyze(req: AnalyzeRequest):
    ticker = req.ticker.upper().strip()
    period = req.period

    try:
        df = fetch_price_data(ticker, period)
    except ValueError as e:
        raise HTTPException(404, str(e))

    company    = get_company_name(ticker)
    news       = fetch_news(ticker, company)
    headlines  = [a["title"] for a in news if a.get("title")]
    features   = compute_features(df, news)
    prediction = predict_risk(features)
    llm_output = analyze_with_llm(ticker, period, features, prediction, headlines)

    close  = df["Close"].squeeze()
    volume = df["Volume"].squeeze()
    dates  = [d.strftime("%Y-%m-%d") for d in df.index]

    n    = len(close)
    ma20 = close.rolling(min(20, n)).mean().bfill()
    ma50 = close.rolling(min(50, n)).mean().bfill()

    return {
        "ticker":    ticker,
        "company":   company,
        "period":    period,
        "prediction": prediction,
        "features":  features,
        "llm":       llm_output,
        "headlines": llm_output.get("headlines", headlines[:5]),
        "chart_data": {
            "dates":  dates,
            "prices": [round(float(p), 2) for p in close],
            "volume": [int(v) for v in volume],
            "ma20":   [round(float(v), 2) for v in ma20],
            "ma50":   [round(float(v), 2) for v in ma50],
        }
    }

@app.get("/health")
def health():
    return {"status": "ok"}