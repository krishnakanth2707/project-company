"""
Training on 30 verified Indian NSE stocks across all 6 time periods.
No expected risk hints — labels assigned purely from computed financial metrics.
"""

import numpy as np
import pandas as pd
import yfinance as yf
import time
import random
import joblib
import os
import warnings
warnings.filterwarnings("ignore")

from sklearn.ensemble import RandomForestClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
import ta

# ── Constants ─────────────────────────────────────────────
RISK_LABELS = ["Very Low", "Low", "Medium", "High", "Very High"]

FEATURES = [
    "roi", "volatility", "price_vs_ma20", "price_vs_ma50",
    "price_vs_ma200", "rsi", "sharpe", "max_drawdown", "news_sentiment"
]

# ── 30 Verified NSE Stocks ────────────────────────────────
STOCKS = [
    "HDFCBANK.NS",
    "TCS.NS",
    "HINDUNILVR.NS",
    "ITC.NS",
    "NESTLEIND.NS",
    "INFY.NS",
    "WIPRO.NS",
    "ICICIBANK.NS",
    "KOTAKBANK.NS",
    "SBIN.NS",
    "RELIANCE.NS",
    "MARUTI.NS",
    "BHARTIARTL.NS",
    "ONGC.NS",
    "SUNPHARMA.NS",
    "TATASTEEL.NS",
    "HINDALCO.NS",
    "DRREDDY.NS",
    "POWERGRID.NS",
    "NTPC.NS",
    "BAJFINANCE.NS",
    "ADANIENT.NS",
    "ADANIPORTS.NS",
    "ZOMATO.NS",
    "TATAPOWER.NS",
    "YESBANK.NS",
    "SUZLON.NS",
    "IDEA.NS",
    "RPOWER.NS",
    "PNB.NS",
]

PERIODS = {
    "1M": "1mo",
    "3M": "3mo",
    "6M": "6mo",
    "1Y": "1y",
    "3Y": "3y",
    "5Y": "5y",
}

PERIOD_FALLBACK = {
    "1mo": ["1mo"],
    "3mo": ["3mo", "1mo"],
    "6mo": ["6mo", "3mo"],
    "1y":  ["1y",  "6mo", "3mo"],
    "3y":  ["3y",  "1y",  "6mo"],
    "5y":  ["5y",  "3y",  "1y",  "6mo"],
}

# ── Download ──────────────────────────────────────────────
def download_stock(ticker: str, yf_period: str, retries: int = 2) -> pd.DataFrame:
    for attempt in range(retries):
        try:
            df = yf.download(
                ticker,
                period=yf_period,
                auto_adjust=True,
                progress=False,
                threads=False,
            )
            if df is not None and not df.empty:
                if isinstance(df.columns, pd.MultiIndex):
                    df.columns = df.columns.get_level_values(0)
                return df
            time.sleep(1 + random.uniform(0.5, 1.0))

        except Exception as e:
            err = str(e).lower()
            if "404" in err or "not found" in err or "delisted" in err:
                return pd.DataFrame()
            elif "rate limit" in err or "429" in err or "too many" in err:
                wait = 8 * (attempt + 1) + random.uniform(2, 4)
                print(f"    Rate limited. Waiting {wait:.0f}s...")
                time.sleep(wait)
            else:
                time.sleep(2)

    return pd.DataFrame()

# ── Feature Computation ───────────────────────────────────
def compute_features_from_df(df: pd.DataFrame):
    try:
        if len(df) < 10:
            return None

        close = df["Close"].squeeze().dropna()
        if len(close) < 10:
            return None

        # ROI
        roi = float((close.iloc[-1] - close.iloc[0]) / close.iloc[0] * 100)

        # Volatility annualised
        daily_returns = close.pct_change().dropna()
        if len(daily_returns) < 2:
            return None
        volatility = float(daily_returns.std() * np.sqrt(252) * 100)

        # Moving averages
        n     = len(close)
        ma20  = float(close.rolling(min(20,  n)).mean().iloc[-1])
        ma50  = float(close.rolling(min(50,  n)).mean().iloc[-1])
        ma200 = float(close.rolling(min(200, n)).mean().iloc[-1])
        price = float(close.iloc[-1])

        price_vs_ma20  = (price - ma20)  / ma20  * 100 if ma20  else 0.0
        price_vs_ma50  = (price - ma50)  / ma50  * 100 if ma50  else 0.0
        price_vs_ma200 = (price - ma200) / ma200 * 100 if ma200 else 0.0

        # RSI
        try:
            rsi = float(
                ta.momentum.RSIIndicator(
                    close, window=min(14, n - 1)
                ).rsi().iloc[-1]
            )
            rsi = 50.0 if np.isnan(rsi) else rsi
        except Exception:
            rsi = 50.0

        # Sharpe
        mean_ret = float(daily_returns.mean())
        std_ret  = float(daily_returns.std())
        sharpe   = float(mean_ret / std_ret * np.sqrt(252)) if std_ret > 0 else 0.0

        # Max drawdown
        roll_max = close.cummax()
        drawdown = (close - roll_max) / roll_max
        max_dd   = float(drawdown.min() * 100)

        def safe(v, fallback=0.0):
            if v is None:
                return fallback
            try:
                f = float(v)
                return fallback if (np.isnan(f) or np.isinf(f)) else round(f, 6)
            except Exception:
                return fallback

        return {
            "roi":            safe(roi),
            "volatility":     safe(volatility),
            "price_vs_ma20":  safe(price_vs_ma20),
            "price_vs_ma50":  safe(price_vs_ma50),
            "price_vs_ma200": safe(price_vs_ma200),
            "rsi":            safe(rsi, 50.0),
            "sharpe":         safe(sharpe),
            "max_drawdown":   safe(max_dd),
            "news_sentiment": 0.0,
        }

    except Exception as e:
        print(f"    Feature error: {e}")
        return None

# ── Risk Label — purely metric driven, no hints ───────────
def assign_risk_label(f: dict) -> str:
    """
    Assigns risk purely from computed financial metrics.
    No expected labels or hints used anywhere.
    Thresholds calibrated for Indian NSE market behaviour.
    """
    vol    = f["volatility"]
    roi    = f["roi"]
    dd     = f["max_drawdown"]
    rsi    = f["rsi"]
    sharpe = f["sharpe"]

    score = 0

    # Volatility — primary driver
    # Indian large caps: 15-25%, mid: 25-40%, small/distressed: 40%+
    if   vol < 10:  score += 0
    elif vol < 18:  score += 1
    elif vol < 28:  score += 2
    elif vol < 42:  score += 3
    elif vol < 60:  score += 4
    else:           score += 5

    # Max drawdown — downside severity
    if   dd > -5:   score += 0
    elif dd > -12:  score += 1
    elif dd > -25:  score += 2
    elif dd > -40:  score += 3
    elif dd > -60:  score += 4
    else:           score += 5

    # Sharpe ratio — risk adjusted return quality
    if   sharpe > 2.0:  score -= 2
    elif sharpe > 1.0:  score -= 1
    elif sharpe > 0.5:  score += 0
    elif sharpe > 0.0:  score += 1
    elif sharpe > -0.5: score += 2
    else:               score += 3

    # ROI direction
    if   roi > 50:  score -= 1
    elif roi > 0:   score += 0
    elif roi > -15: score += 1
    elif roi > -30: score += 2
    else:           score += 3

    # RSI extremes — momentum overextension
    if   rsi > 80: score += 2
    elif rsi > 70: score += 1
    elif rsi < 20: score += 2
    elif rsi < 30: score += 1

    score = max(0, min(score, 14))

    if   score <= 2:  return "Very Low"
    elif score <= 5:  return "Low"
    elif score <= 8:  return "Medium"
    elif score <= 11: return "High"
    else:             return "Very High"

# ── Build Dataset ─────────────────────────────────────────
def build_dataset() -> pd.DataFrame:
    records = []
    total   = len(STOCKS) * len(PERIODS)
    done    = 0

    print(f"\n{'='*60}")
    print(f"Downloading: {len(STOCKS)} NSE stocks x {len(PERIODS)} periods")
    print(f"Labels assigned purely from financial metrics")
    print(f"{'='*60}\n")

    for ticker in STOCKS:
        print(f"[{ticker}]")
        collected = 0

        for period_label, yf_period in PERIODS.items():
            done += 1
            tag = f"  [{done:3d}/{total}] {period_label}"

            df = pd.DataFrame()
            for fallback in PERIOD_FALLBACK.get(yf_period, [yf_period]):
                df = download_stock(ticker, fallback)
                if not df.empty:
                    break
                time.sleep(0.5)

            if df.empty:
                print(f"{tag} -> SKIP (no data)")
                continue

            features = compute_features_from_df(df)
            if features is None:
                print(f"{tag} -> SKIP (feature error)")
                continue

            label = assign_risk_label(features)
            features["label"]  = label
            features["ticker"] = ticker
            features["period"] = period_label
            records.append(features)
            collected += 1

            print(
                f"{tag} -> {label:10s} | "
                f"vol={features['volatility']:5.1f}% "
                f"roi={features['roi']:7.1f}% "
                f"dd={features['max_drawdown']:6.1f}% "
                f"sharpe={features['sharpe']:5.2f}"
            )

            time.sleep(random.uniform(0.8, 1.4))

        print(f"  -> {collected}/6 periods collected\n")
        time.sleep(random.uniform(1.2, 2.0))

    return pd.DataFrame(records)

# ── Augment ───────────────────────────────────────────────
def augment_dataset(df: pd.DataFrame, target_per_class: int = 80) -> pd.DataFrame:
    """
    Adds small Gaussian noise (5% scale) to real samples
    to reach target_per_class per label.
    Preserves the real financial distributions.
    """
    augmented = [df]

    print(f"\n{'='*60}")
    print("Augmenting dataset to balance classes...")

    for label in RISK_LABELS:
        subset = df[df["label"] == label]
        n_real = len(subset)

        if n_real == 0:
            print(f"  {label:12s}: NO REAL DATA — will rely on SMOTE only")
            continue

        n_needed = max(0, target_per_class - n_real)
        print(f"  {label:12s}: {n_real:3d} real -> +{n_needed} synthetic")

        if n_needed == 0:
            continue

        rows = []
        for _ in range(n_needed):
            base  = subset.sample(1).iloc[0]
            noisy = {}
            for feat in FEATURES:
                val         = float(base[feat])
                noise_scale = abs(val) * 0.05 + 0.001
                noisy[feat] = val + np.random.normal(0, noise_scale)
            noisy["label"]  = label
            noisy["ticker"] = base["ticker"]
            noisy["period"] = base["period"]
            rows.append(noisy)

        augmented.append(pd.DataFrame(rows))

    return pd.concat(augmented, ignore_index=True)

# ── Train & Save ──────────────────────────────────────────
def train_and_save(model_path: str = "models/risk_model.pkl"):
    os.makedirs("models", exist_ok=True)
    np.random.seed(42)

    # Step 1: Download
    df = build_dataset()

    if df.empty:
        raise RuntimeError("No data downloaded. Check hotspot/internet.")

    print(f"\n{'='*60}")
    print(f"Real dataset : {len(df)} samples from {df['ticker'].nunique()} tickers")
    print(f"\nLabel distribution (real data — no hints used):")
    real_counts = df["label"].value_counts()
    for label in RISK_LABELS:
        count = real_counts.get(label, 0)
        bar   = "█" * count
        print(f"  {label:12s}: {count:3d} {bar}")

    # Step 2: Augment
    df_aug = augment_dataset(df, target_per_class=80)

    print(f"\nAugmented    : {len(df_aug)} total samples")
    print(f"\nLabel distribution (after augmentation):")
    aug_counts = df_aug["label"].value_counts()
    for label in RISK_LABELS:
        count = aug_counts.get(label, 0)
        bar   = "█" * min(count, 40)
        print(f"  {label:12s}: {count:3d} {bar}")

    # Step 3: Prepare arrays
    X     = df_aug[FEATURES].values.astype(np.float64)
    y     = df_aug["label"].values
    le    = LabelEncoder()
    le.fit(RISK_LABELS)
    y_enc = le.transform(y)

    min_class_size = int(aug_counts.min())
    print(f"\nMin class size: {min_class_size}")

    if min_class_size < 4:
        raise RuntimeError(
            f"Min class size {min_class_size} is too small. "
            f"Check that NSE tickers are downloadable."
        )

    # Step 4: SMOTE + RandomForest
    k_neighbors = max(1, min(5, min_class_size - 1))

    print(f"\n{'='*60}")
    print(f"Building pipeline: SMOTE(k={k_neighbors}) + RandomForest(500 trees)")

    rf = RandomForestClassifier(
        n_estimators=500,
        max_depth=15,
        min_samples_leaf=2,
        min_samples_split=4,
        max_features="sqrt",
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )

    pipeline = ImbPipeline([
        ("smote", SMOTE(random_state=42, k_neighbors=k_neighbors)),
        ("clf",   rf),
    ])

    # Step 5: Cross-validation
    n_splits  = max(2, min(5, min_class_size))
    print(f"Running {n_splits}-fold Stratified CV...")

    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
    cv_scores = cross_val_score(
        pipeline, X, y_enc,
        cv=skf,
        scoring="accuracy",
        n_jobs=-1,
    )

    print(f"\n{'='*60}")
    print(f"CV Accuracy per fold : {[f'{s*100:.1f}%' for s in cv_scores]}")
    print(f"CV Mean Accuracy     : {cv_scores.mean()*100:.1f}%")
    print(f"CV Std Dev           : {cv_scores.std()*100:.1f}%")

    if cv_scores.mean() < 0.78:
        raise RuntimeError(
            f"CV accuracy {cv_scores.mean()*100:.1f}% below 78% threshold. "
            f"Check feature quality and label consistency."
        )

    # Step 6: Fit final model
    print("\nFitting final model on full dataset...")
    pipeline.fit(X, y_enc)

    # Step 7: Calibrate probabilities
    print("Calibrating probabilities...")
    rf_fitted   = pipeline.named_steps["clf"]
    X_sm, y_sm  = SMOTE(
        random_state=42, k_neighbors=k_neighbors
    ).fit_resample(X, y_enc)

    cal_cv      = max(2, min(5, int(np.bincount(y_sm).min())))
    calibrated  = CalibratedClassifierCV(
        rf_fitted, method="isotonic", cv=cal_cv
    )
    calibrated.fit(X_sm, y_sm)

    # Step 8: Evaluation report
    y_pred = calibrated.predict(X_sm)
    print(f"\n{'='*60}")
    print("Classification Report:")
    print(classification_report(y_sm, y_pred, target_names=le.classes_))

    print("Confusion Matrix:")
    cm = confusion_matrix(y_sm, y_pred)
    cm_df = pd.DataFrame(cm, index=le.classes_, columns=le.classes_)
    print(cm_df)

    # Step 9: Save artifact
    artifact = {
        "pipeline":      pipeline,
        "calibrated":    calibrated,
        "label_encoder": le,
        "features":      FEATURES,
        "cv_mean":       float(cv_scores.mean()),
        "cv_std":        float(cv_scores.std()),
        "n_real":        len(df),
        "n_total":       len(df_aug),
        "tickers":       list(df["ticker"].unique()),
        "market":        "NSE India",
        "risk_labels":   RISK_LABELS,
    }

    # Save training dataset as CSV
    csv_path = "models/training_dataset.csv"
    df_aug.to_csv(csv_path, index=False)
    print(f"  Training CSV saved: {csv_path}")
    
    joblib.dump(artifact, model_path)

    print(f"\n{'='*60}")
    print(f"  Model saved    : {model_path}")
    print(f"  Real samples   : {len(df)}")
    print(f"  Total samples  : {len(df_aug)}")
    print(f"  CV Accuracy    : {cv_scores.mean()*100:.1f}%")
    print(f"  Stocks trained : {df['ticker'].nunique()} NSE stocks")
    print(f"  Market         : NSE India (.NS)")
    print(f"{'='*60}\n")

if __name__ == "__main__":
    train_and_save()