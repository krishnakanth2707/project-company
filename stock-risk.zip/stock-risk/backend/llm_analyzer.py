import requests
import os
from dotenv import load_dotenv

load_dotenv()
HF_TOKEN = os.getenv("HF_TOKEN")

# These models use the text-generation pipeline on free HF inference
HF_MODELS = [
    "mistralai/Mistral-7B-Instruct-v0.1",
    "google/flan-t5-xl",
    "declare-lab/flan-alpaca-large",
    "tiiuae/falcon-7b-instruct",
]

def call_hf_model(model: str, prompt: str) -> str:
    url     = f"https://api-inference.huggingface.co/models/{model}"
    headers = {
        "Authorization": f"Bearer {HF_TOKEN}",
        "Content-Type":  "application/json",
    }
    payload = {
        "inputs": prompt,
        "parameters": {
            "max_new_tokens":  450,
            "temperature":     0.4,
            "top_p":           0.9,
            "do_sample":       True,
            "return_full_text": False,
        },
        "options": {
            "wait_for_model": True,
            "use_cache":      False,
        },
    }
    resp = requests.post(url, headers=headers, json=payload, timeout=120)

    if resp.status_code in [404, 400]:
        raise ValueError(f"Model unavailable: {model}")
    if resp.status_code == 503:
        raise ValueError(f"Model loading (503): {model}")
    if resp.status_code == 401:
        raise ValueError("Invalid HuggingFace token")

    resp.raise_for_status()
    data = resp.json()

    if isinstance(data, list) and data:
        text = data[0].get("generated_text", "")
        if text and len(text.strip()) > 60:
            return text
        raise ValueError(f"Empty response from {model}")

    if isinstance(data, dict):
        if "error" in data:
            raise ValueError(data["error"])
        return data.get("generated_text", "")

    raise ValueError(f"Unexpected response format from {model}")

def build_prompt(ticker: str, period: str, features: dict,
                 prediction: dict, news_headlines: list) -> str:
    headlines = "\n".join(
        f"- {h}" for h in news_headlines[:5]
    ) or "No recent news available."

    proba_str = ", ".join(
        f"{k}: {v*100:.1f}%" for k, v in prediction["probabilities"].items()
    )

    return f"""You are a professional Indian stock market risk analyst. 
Respond only in English. Be concise and professional.

Stock: {ticker} | Period: {period}
Risk Level: {prediction['risk_label']} (Confidence: {prediction['confidence']*100:.1f}%)
Class Probabilities: {proba_str}
ROI: {features['roi']:.2f}% | Volatility: {features['volatility']:.2f}% | RSI: {features['rsi']:.1f}
Sharpe Ratio: {features['sharpe']:.2f} | Max Drawdown: {features['max_drawdown']:.2f}%
Price vs MA50: {features['price_vs_ma50']:.2f}% | News Sentiment: {features['news_sentiment']:.3f}

Recent News Headlines (English):
{headlines}

Write exactly three sections in English only:

CURRENT MARKET SUMMARY
Write 2-3 sentences about the current price trend and momentum.

RISK EXPLANATION
Write 2-3 sentences explaining why this risk level was assigned using the metrics.

INVESTMENT OUTLOOK
Write 2-3 sentences on investment considerations and any caution flags.
"""

def generate_fallback(ticker: str, period: str, features: dict,
                      prediction: dict, news_headlines: list) -> dict:
    """
    Intelligent rule-based fallback in English.
    Produces meaningful output from real metrics when LLM unavailable.
    """
    roi       = features.get("roi", 0)
    vol       = features.get("volatility", 0)
    rsi       = features.get("rsi", 50)
    sharpe    = features.get("sharpe", 0)
    sentiment = features.get("news_sentiment", 0)
    dd        = features.get("max_drawdown", 0)
    ma50      = features.get("price_vs_ma50", 0)
    risk      = prediction["risk_label"]
    conf      = prediction["confidence"] * 100

    trend     = "upward" if roi > 0 else "downward"
    ma_pos    = "above" if ma50 > 0 else "below"
    rsi_desc  = (
        "overbought, signalling a potential pullback"   if rsi > 70 else
        "oversold, signalling a potential recovery"     if rsi < 30 else
        "in neutral territory"
    )
    vol_desc  = (
        "extremely high" if vol > 60 else
        "high"           if vol > 40 else
        "moderate"       if vol > 20 else
        "low"
    )
    sent_desc = (
        "positive, reflecting bullish news flow"        if sentiment > 0.1  else
        "negative, reflecting bearish news sentiment"   if sentiment < -0.1 else
        "neutral"
    )
    sharpe_desc = (
        "strong risk-adjusted returns"   if sharpe > 1.0  else
        "weak risk-adjusted returns"     if sharpe < 0.0  else
        "moderate risk-adjusted returns"
    )

    # Market summary
    summary = (
        f"{ticker} has posted a {roi:.2f}% return over the {period} period, "
        f"reflecting a clear {trend} price trend on the NSE. "
        f"The stock is currently trading {ma_pos} its 50-day moving average "
        f"by {abs(ma50):.1f}%, with RSI at {rsi:.1f} placing it {rsi_desc}. "
        f"Maximum drawdown during this period was {abs(dd):.2f}%."
    )

    # Risk explanation
    explanation = (
        f"The {risk} risk classification (confidence: {conf:.1f}%) is primarily "
        f"driven by {vol_desc} annualised volatility of {vol:.2f}%, "
        f"indicating {sharpe_desc} with a Sharpe ratio of {sharpe:.2f}. "
        f"News sentiment is {sent_desc}, which "
        f"{'supports' if (sentiment >= 0 and roi >= 0) else 'contrasts with'} "
        f"the quantitative risk signals from price data."
    )

    # Investment outlook by risk level
    if risk == "Very High":
        outlook = (
            f"{ticker} is classified as very high risk and is appropriate "
            f"only for aggressive traders with strong risk tolerance on NSE. "
            f"Strict stop-loss levels and minimal position sizing are essential. "
            f"Current news sentiment is {sent_desc} — monitor for sharp reversals."
        )
    elif risk == "High":
        outlook = (
            f"{ticker} carries elevated risk over the {period} horizon, "
            f"requiring disciplined position management for NSE investors. "
            f"Consider waiting for RSI to normalise before entering new positions. "
            f"News sentiment is currently {sent_desc}."
        )
    elif risk == "Medium":
        outlook = (
            f"{ticker} presents a balanced risk-reward profile for the {period} period, "
            f"suitable for investors with moderate risk appetite on NSE. "
            f"Watch for moving average crossovers as entry/exit signals. "
            f"News sentiment is {sent_desc}."
        )
    elif risk == "Low":
        outlook = (
            f"{ticker} is a relatively stable NSE investment over the {period} period, "
            f"suited for conservative investors seeking steady returns. "
            f"The low volatility and {sharpe_desc} support a hold or accumulate strategy. "
            f"News sentiment is {sent_desc}."
        )
    else:  # Very Low
        outlook = (
            f"{ticker} demonstrates very low risk on NSE over the {period} period, "
            f"making it suitable for capital-preservation-focused investors. "
            f"The low drawdown and {sharpe_desc} support long-term portfolio allocation. "
            f"News sentiment is {sent_desc}."
        )

    return {
        "market_summary":     summary,
        "risk_explanation":   explanation,
        "investment_outlook": outlook,
        "raw":                "Generated by rule-based fallback (English).",
        "headlines":          [h for h in news_headlines[:5] if h],
    }

def parse_llm_output(text: str) -> dict:
    sections = {
        "market_summary":     "",
        "risk_explanation":   "",
        "investment_outlook": "",
        "raw":                text,
    }
    current = None

    for line in text.split("\n"):
        l = line.strip()
        if not l:
            continue
        lu = l.upper()
        if "CURRENT MARKET SUMMARY" in lu:
            current = "market_summary"
            continue
        elif "RISK EXPLANATION" in lu:
            current = "risk_explanation"
            continue
        elif "INVESTMENT OUTLOOK" in lu:
            current = "investment_outlook"
            continue

        if current:
            # Skip markdown headers and decorators
            if l.startswith(("#", "**", "---", "===")):
                continue
            sections[current] += l + " "

    # Clean whitespace
    for k in ["market_summary", "risk_explanation", "investment_outlook"]:
        sections[k] = sections[k].strip()

    # If parsing failed split raw into thirds
    populated = sum(1 for k in ["market_summary", "risk_explanation", "investment_outlook"]
                    if sections[k])
    if populated < 2:
        sentences = [
            s.strip() for s in text.replace("\n", " ").split(".")
            if s.strip() and len(s.strip()) > 10
        ]
        third = max(1, len(sentences) // 3)
        sections["market_summary"]     = ". ".join(sentences[:third]).strip() + "."
        sections["risk_explanation"]   = ". ".join(sentences[third:third*2]).strip() + "."
        sections["investment_outlook"] = ". ".join(sentences[third*2:]).strip() + "."

    return sections

def analyze_with_llm(ticker: str, period: str, features: dict,
                     prediction: dict, news_headlines: list) -> dict:
    # Try HuggingFace models
    if HF_TOKEN and HF_TOKEN != "your_huggingface_token_here":
        prompt = build_prompt(ticker, period, features, prediction, news_headlines)
        for model in HF_MODELS:
            try:
                print(f"Trying HF model: {model}")
                text = call_hf_model(model, prompt)
                if text and len(text.strip()) > 80:
                    parsed = parse_llm_output(text)
                    populated = sum(
                        1 for k in ["market_summary", "risk_explanation", "investment_outlook"]
                        if parsed[k] and len(parsed[k]) > 20
                    )
                    if populated >= 2:
                        parsed["headlines"] = [h for h in news_headlines[:5] if h]
                        print(f"LLM success with: {model}")
                        return parsed
            except Exception as e:
                print(f"  {model} failed: {e}")
                continue

    # Fallback — always English, always meaningful
    print("Using intelligent English rule-based fallback.")
    return generate_fallback(ticker, period, features, prediction, news_headlines)