import pandas as pd
import numpy as np
from textblob import TextBlob
import ta

FEATURES = [
    "roi", "volatility", "price_vs_ma20", "price_vs_ma50",
    "price_vs_ma200", "rsi", "sharpe", "max_drawdown", "news_sentiment"
]

def compute_features(df: pd.DataFrame, news_articles: list) -> dict:
    close = df["Close"].squeeze()

    # ── ROI ──────────────────────────────────────────────
    roi = float((close.iloc[-1] - close.iloc[0]) / close.iloc[0] * 100)

    # ── Volatility (annualised) ───────────────────────────
    daily_returns = close.pct_change().dropna()
    volatility = float(daily_returns.std() * np.sqrt(252) * 100)

    # ── Moving Averages ───────────────────────────────────
    ma20  = float(close.rolling(min(20,  len(close))).mean().iloc[-1])
    ma50  = float(close.rolling(min(50,  len(close))).mean().iloc[-1])
    ma200 = float(close.rolling(min(200, len(close))).mean().iloc[-1])
    price = float(close.iloc[-1])

    # Price vs MA ratios (scale-free)
    price_vs_ma20  = (price - ma20)  / ma20  * 100 if ma20  else 0.0
    price_vs_ma50  = (price - ma50)  / ma50  * 100 if ma50  else 0.0
    price_vs_ma200 = (price - ma200) / ma200 * 100 if ma200 else 0.0

    # ── RSI ──────────────────────────────────────────────
    try:
        rsi = float(ta.momentum.RSIIndicator(close, window=14).rsi().iloc[-1])
    except Exception:
        rsi = 50.0

    # ── Sharpe-like ratio ─────────────────────────────────
    mean_ret = daily_returns.mean()
    std_ret  = daily_returns.std()
    sharpe   = float(mean_ret / std_ret * np.sqrt(252)) if std_ret else 0.0

    # ── Max drawdown ──────────────────────────────────────
    roll_max = close.cummax()
    drawdown = (close - roll_max) / roll_max
    max_dd   = float(drawdown.min() * 100)

    # ── News sentiment ────────────────────────────────────
    sentiments = []
    for art in news_articles[:15]:
        text = f"{art.get('title', '')} {art.get('description', '')}"
        try:
            blob = TextBlob(text)
            sentiments.append(blob.sentiment.polarity)
        except Exception:
            sentiments.append(0.0)

    avg_sentiment = float(np.mean(sentiments)) if sentiments else 0.0
    news_count    = len(news_articles)

    # ── NaN / Inf guard ──────────────────────────────────
    def safe(v, fallback=0.0):
        if v is None or (isinstance(v, float) and (np.isnan(v) or np.isinf(v))):
            return fallback
        return v

    return {
        # Model features (must match FEATURES list exactly)
        "roi":            safe(roi),
        "volatility":     safe(volatility),
        "price_vs_ma20":  safe(price_vs_ma20),
        "price_vs_ma50":  safe(price_vs_ma50),
        "price_vs_ma200": safe(price_vs_ma200),
        "rsi":            safe(rsi, 50.0),
        "sharpe":         safe(sharpe),
        "max_drawdown":   safe(max_dd),
        "news_sentiment": safe(avg_sentiment),

        # Extra fields for display (not used by model)
        "news_count":     news_count,
        "current_price":  safe(price),
        "ma20":           safe(ma20),
        "ma50":           safe(ma50),
        "ma200":          safe(ma200),
    }