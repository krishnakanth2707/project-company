import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000/analyze"

# ALL STOCKS
INDIAN_STOCKS = [
    {"ticker": "HDFCBANK.NS",   "name": "HDFC Bank"},
    {"ticker": "TCS.NS",        "name": "Tata Consultancy Services"},
    {"ticker": "HINDUNILVR.NS", "name": "Hindustan Unilever"},
    {"ticker": "ITC.NS",        "name": "ITC Limited"},
    {"ticker": "NESTLEIND.NS",  "name": "Nestle India"},
    {"ticker": "INFY.NS",       "name": "Infosys"},
    {"ticker": "WIPRO.NS",      "name": "Wipro"},
    {"ticker": "ICICIBANK.NS",  "name": "ICICI Bank"},
    {"ticker": "KOTAKBANK.NS",  "name": "Kotak Mahindra Bank"},
    {"ticker": "SBIN.NS",       "name": "State Bank of India"},
    {"ticker": "RELIANCE.NS",   "name": "Reliance Industries"},
    {"ticker": "MARUTI.NS",     "name": "Maruti Suzuki"},
    {"ticker": "BHARTIARTL.NS", "name": "Bharti Airtel"},
    {"ticker": "ONGC.NS",       "name": "Oil & Natural Gas Corp"},
    {"ticker": "SUNPHARMA.NS",  "name": "Sun Pharmaceutical"},
    {"ticker": "TATASTEEL.NS",  "name": "Tata Steel"},
    {"ticker": "HINDALCO.NS",   "name": "Hindalco Industries"},
    {"ticker": "DRREDDY.NS",    "name": "Dr Reddy's Laboratories"},
    {"ticker": "POWERGRID.NS",  "name": "Power Grid Corp"},
    {"ticker": "NTPC.NS",       "name": "NTPC"},
    {"ticker": "BAJFINANCE.NS", "name": "Bajaj Finance"},
    {"ticker": "ADANIENT.NS",   "name": "Adani Enterprises"},
    {"ticker": "ADANIPORTS.NS", "name": "Adani Ports"},
    {"ticker": "ZOMATO.NS",     "name": "Zomato"},
    {"ticker": "TATAPOWER.NS",  "name": "Tata Power"},
    {"ticker": "YESBANK.NS",    "name": "Yes Bank"},
    {"ticker": "SUZLON.NS",     "name": "Suzlon Energy"},
    {"ticker": "IDEA.NS",       "name": "Vodafone Idea"},
    {"ticker": "RPOWER.NS",     "name": "Reliance Power"},
    {"ticker": "PNB.NS",        "name": "Punjab National Bank"},
]

PERIODS = ["1M", "3M", "6M", "1Y", "3Y", "5Y"]

st.set_page_config(
    page_title="Stock Risk Analyzer",
    page_icon="📈",
    layout="centered"
)

st.title("📈 Stock Risk Analyzer")

# Dropdown stock selection
selected_stock = st.selectbox(
    "Select Company",
    INDIAN_STOCKS,
    format_func=lambda x: f"{x['name']} ({x['ticker']})"
)

# Period selection
period = st.selectbox(
    "Select Time Period",
    PERIODS,
    index=3
)

# Analyze button
if st.button("Analyse Risk"):

    try:
        with st.spinner("Analysing stock risk..."):

            response = requests.post(
                API_URL,
                json={
                    "ticker": selected_stock["ticker"],
                    "period": period
                }
            )

            data = response.json()

            # ONLY SHOW RISK LABEL
            risk = data["prediction"]["risk_label"]

        # ONLY SHOW REQUIRED OUTPUTS

        current_price = data["features"]["current_price"]
        risk_explanation = data["llm"]["risk_explanation"]

        st.markdown("---")

        # Current Price
        st.markdown("### 💰 Current Stock Price")
        st.info(f"₹ {float(current_price):.2f}")

        # Risk Label
        st.markdown("### ⚠️ Risk Level")

        if risk.lower() == "low":
            st.success(f"🟢 {risk} Risk")

        elif risk.lower() == "medium":
            st.warning(f"🟡 {risk} Risk")

        else:
            st.error(f"🔴 {risk} Risk")

        # Risk Explanation
        st.markdown("### 🧠 Risk Explanation")

        st.markdown(
            f"""
        <div style="
            background-color:#f3f4f6;
            padding:18px;
            border-radius:12px;
            color:#111827;
            font-size:16px;
            line-height:1.7;
        ">
        {risk_explanation}
        </div>
        """,
            unsafe_allow_html=True
        )

    except Exception as e:
        st.error(f"Error: {str(e)}")