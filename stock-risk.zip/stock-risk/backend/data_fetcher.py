import yfinance as yf
import requests
import pandas as pd
from datetime import datetime, timedelta
from dotenv import load_dotenv
import os
import ssl
import urllib3
import time
import random

# ── SSL fix for corporate networks ───────────────────────
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
ssl._create_default_https_context = ssl._create_unverified_context

load_dotenv()
NEWS_API_KEY = os.getenv("NEWS_API_KEY")

PERIOD_MAP = {
    "1M": "1mo",
    "3M": "3mo",
    "6M": "6mo",
    "1Y": "1y",
    "3Y": "3y",
    "5Y": "5y",
}

def fetch_price_data(ticker: str, period: str, retries: int = 5) -> pd.DataFrame:
    yf_period = PERIOD_MAP.get(period, "1y")
    last_error = None

    for attempt in range(retries):
        try:
            # Use yf.download with period string — most stable method
            df = yf.download(
                ticker,
                period=yf_period,
                auto_adjust=True,
                progress=False,
                threads=False,
            )

            if df is not None and not df.empty:
                # Flatten MultiIndex columns if present
                if isinstance(df.columns, pd.MultiIndex):
                    df.columns = df.columns.get_level_values(0)
                return df

            wait = 3 * (attempt + 1) + random.uniform(1, 3)
            print(f"[Attempt {attempt+1}] Empty data for {ticker}, retrying in {wait:.1f}s...")
            time.sleep(wait)

        except Exception as e:
            last_error = e
            err_str = str(e).lower()

            if "rate limit" in err_str or "too many requests" in err_str or "429" in err_str:
                wait = 10 * (attempt + 1) + random.uniform(3, 8)
                print(f"[Attempt {attempt+1}] Rate limited. Waiting {wait:.1f}s...")
                time.sleep(wait)
            else:
                wait = 3 + random.uniform(1, 3)
                print(f"[Attempt {attempt+1}] Error: {e}. Retrying in {wait:.1f}s...")
                time.sleep(wait)

    raise ValueError(
        f"Could not fetch data for '{ticker}'. "
        f"Yahoo Finance is rate limiting your network. "
        f"Please wait 2-3 minutes and try again."
    )

def fetch_news(ticker: str, company_name: str = None) -> list:
    if not NEWS_API_KEY:
        return []
    query = company_name or ticker
    url = "https://newsapi.org/v2/everything"
    params = {
        "q": query,
        "language": "en",
        "sortBy": "publishedAt",
        "pageSize": 20,
        "apiKey": NEWS_API_KEY,
    }
    try:
        resp = requests.get(url, params=params, timeout=10, verify=False)
        if resp.status_code != 200:
            return []
        return resp.json().get("articles", [])
    except Exception:
        return []

def get_company_name(ticker: str) -> str:
    try:
        tk = yf.Ticker(ticker)
        info = tk.fast_info
        return getattr(info, "display_name", None) or ticker
    except Exception:
        return ticker