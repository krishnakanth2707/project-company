import { Lightbulb } from "lucide-react";

export default function InvestmentOutlook({ text, headlines }) {
  return (
    <div style={card}>
      <div style={header}>
        <div style={iconBox}><Lightbulb size={16} color="#f59e0b" /></div>
        <span style={title}>Investment Outlook</span>
      </div>
      <p style={body}>{text || "Loading..."}</p>
      {headlines?.length > 0 && (
        <>
          <div style={newsTitle}>Latest News</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
            {headlines.slice(0, 4).map((h, i) => (
              <div key={i} style={newsItem}>
                <div style={newsDot} />
                <span style={newsText}>{h}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

const card = {
  background: "rgba(30,41,59,0.8)",
  border: "1px solid rgba(245,158,11,0.2)",
  borderRadius: 14, padding: 20,
  backdropFilter: "blur(8px)",
};
const header   = { display: "flex", alignItems: "center", gap: 10, marginBottom: 14 };
const iconBox  = { background: "#f59e0b20", borderRadius: 8, padding: 7, display: "flex" };
const title    = { fontWeight: 700, fontSize: 14, color: "#e2e8f0" };
const body     = { fontSize: 13, color: "#94a3b8", lineHeight: 1.7, margin: "0 0 14px" };
const newsTitle = { fontSize: 12, fontWeight: 600, color: "#64748b", marginBottom: 8, textTransform: "uppercase", letterSpacing: "0.05em" };
const newsItem  = { display: "flex", alignItems: "flex-start", gap: 8 };
const newsDot   = { width: 5, height: 5, borderRadius: "50%", background: "#f59e0b", marginTop: 6, flexShrink: 0 };
const newsText  = { fontSize: 12, color: "#64748b", lineHeight: 1.5 };