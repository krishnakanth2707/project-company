import {
  LineChart, Line, BarChart, Bar, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, ReferenceLine, Cell,
} from "recharts";

const RISK_COLORS = {
  "Very Low": "#10b981", "Low": "#3b82f6",
  "Medium": "#f59e0b", "High": "#f97316", "Very High": "#ef4444",
};

// Downsample array to max N points
function downsample(arr, max = 100) {
  if (arr.length <= max) return arr;
  const step = Math.ceil(arr.length / max);
  return arr.filter((_, i) => i % step === 0);
}

// Custom dark tooltip
const DarkTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: "rgba(15,23,42,0.97)",
      border: "1px solid rgba(99,102,241,0.3)",
      borderRadius: 8, padding: "10px 14px", fontSize: 12,
    }}>
      <div style={{ color: "#94a3b8", marginBottom: 6 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color: p.color, fontWeight: 600 }}>
          {p.name}: {typeof p.value === "number"
            ? p.name.toLowerCase().includes("volume")
              ? `${(p.value / 1e6).toFixed(2)}M`
              : p.value.toFixed(2)
            : p.value}
        </div>
      ))}
    </div>
  );
};

export default function StockCharts({ data, ticker, probabilities }) {
  if (!data?.dates?.length) return null;

  const indices = downsample(data.dates.map((_, i) => i), 100);

  // Chart 1: Price + MA
  const priceData = indices.map(i => ({
    date:  data.dates[i].slice(5),
    Price: data.prices[i],
    MA20:  data.ma20[i],
    MA50:  data.ma50[i],
  }));

  // Chart 2: Volume bars
  const volData = indices.map(i => ({
    date:   data.dates[i].slice(5),
    Volume: data.volume[i],
  }));

  // Chart 3: Rolling 20-day volatility
  const prices = data.prices;
  const rollingVol = data.dates.map((date, i) => {
    if (i < 20) return null;
    const slice = prices.slice(i - 20, i);
    const rets  = slice.slice(1).map((p, j) => Math.log(p / slice[j]));
    const mean  = rets.reduce((a, b) => a + b, 0) / rets.length;
    const std   = Math.sqrt(rets.reduce((s, r) => s + (r - mean) ** 2, 0) / rets.length);
    return { date: date.slice(5), Volatility: +(std * Math.sqrt(252) * 100).toFixed(2) };
  }).filter(Boolean);
  const rollingVolDS = downsample(rollingVol, 100);

  // Chart 4: Risk probability bar chart
  const riskData = Object.entries(probabilities || {}).map(([label, value]) => ({
    label,
    Probability: +(value * 100).toFixed(1),
  }));

  const axisStyle = { fill: "#64748b", fontSize: 11 };
  const gridProps = { strokeDasharray: "3 3", stroke: "rgba(99,102,241,0.1)" };

  return (
    <div>
      <div style={sectionTitle}>
        <span style={sectionDot} />
        Market Charts — {ticker}
      </div>

      <div style={chartGrid}>

        {/* Chart 1 — Price & Moving Averages */}
        <div style={chartCard}>
          <div style={chartTitle}>📈 Price & Moving Averages</div>
          <div style={chartSub}>Closing price with 20-day and 50-day moving averages</div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={priceData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <CartesianGrid {...gridProps} />
              <XAxis dataKey="date" tick={axisStyle} interval="preserveStartEnd" />
              <YAxis tick={axisStyle} width={60} tickFormatter={v => `₹${v.toFixed(0)}`} />
              <Tooltip content={<DarkTooltip />} />
              <Legend wrapperStyle={{ fontSize: 12, color: "#94a3b8" }} />
              <Line dataKey="Price" stroke="#6366f1" dot={false} strokeWidth={2.5} name="Price" />
              <Line dataKey="MA20"  stroke="#f59e0b" dot={false} strokeWidth={1.5} name="MA20" strokeDasharray="5 3" />
              <Line dataKey="MA50"  stroke="#10b981" dot={false} strokeWidth={1.5} name="MA50" strokeDasharray="5 3" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 2 — Volume */}
        <div style={chartCard}>
          <div style={chartTitle}>📊 Trading Volume</div>
          <div style={chartSub}>Daily traded volume — spikes indicate high activity</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={volData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <CartesianGrid {...gridProps} />
              <XAxis dataKey="date" tick={axisStyle} interval="preserveStartEnd" />
              <YAxis tick={axisStyle} width={60} tickFormatter={v => `${(v / 1e6).toFixed(0)}M`} />
              <Tooltip content={<DarkTooltip />} />
              <Bar dataKey="Volume" name="Volume" radius={[2, 2, 0, 0]}>
                {volData.map((_, i) => (
                  <Cell
                    key={i}
                    fill={i % 2 === 0 ? "rgba(99,102,241,0.7)" : "rgba(139,92,246,0.7)"}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 3 — Rolling Volatility */}
        <div style={chartCard}>
          <div style={chartTitle}>🌊 Rolling Volatility</div>
          <div style={chartSub}>20-day annualised volatility — higher means more risk</div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={rollingVolDS} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <defs>
                <linearGradient id="volGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#ef4444" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid {...gridProps} />
              <XAxis dataKey="date" tick={axisStyle} interval="preserveStartEnd" />
              <YAxis tick={axisStyle} width={45} tickFormatter={v => `${v.toFixed(0)}%`} />
              <Tooltip content={<DarkTooltip />} />
              <ReferenceLine y={30} stroke="#f59e0b" strokeDasharray="4 2"
                label={{ value: "High risk", fill: "#f59e0b", fontSize: 10 }} />
              <Area
                dataKey="Volatility" name="Volatility %"
                stroke="#ef4444" strokeWidth={2}
                fill="url(#volGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Chart 4 — Risk Probability Distribution */}
        <div style={chartCard}>
          <div style={chartTitle}>🎯 Risk Probability Distribution</div>
          <div style={chartSub}>AI model confidence across all 5 risk categories</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart
              data={riskData}
              layout="vertical"
              margin={{ top: 5, right: 20, left: 70, bottom: 5 }}
            >
              <CartesianGrid {...gridProps} horizontal={false} />
              <XAxis
                type="number" tick={axisStyle}
                tickFormatter={v => `${v}%`} domain={[0, 100]}
              />
              <YAxis
                type="category" dataKey="label"
                tick={{ fill: "#94a3b8", fontSize: 12 }} width={70}
              />
              <Tooltip content={<DarkTooltip />} />
              <Bar dataKey="Probability" name="Probability %" radius={[0, 4, 4, 0]}>
                {riskData.map((entry, i) => (
                  <Cell
                    key={i}
                    fill={RISK_COLORS[entry.label] || "#6366f1"}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

      </div>
    </div>
  );
}

const sectionTitle = {
  display: "flex", alignItems: "center", gap: 10,
  fontSize: 16, fontWeight: 700, color: "#e2e8f0",
  marginBottom: 16,
};
const sectionDot = {
  display: "inline-block", width: 4, height: 20,
  background: "linear-gradient(180deg, #6366f1, #8b5cf6)",
  borderRadius: 2,
};
const chartGrid = {
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: 16, marginBottom: 32,
};
const chartCard = {
  background: "rgba(30,41,59,0.8)",
  border: "1px solid rgba(99,102,241,0.15)",
  borderRadius: 14, padding: "20px 16px",
  backdropFilter: "blur(8px)",
};
const chartTitle = { fontSize: 14, fontWeight: 700, color: "#e2e8f0", marginBottom: 4 };
const chartSub   = { fontSize: 12, color: "#64748b", marginBottom: 14 };