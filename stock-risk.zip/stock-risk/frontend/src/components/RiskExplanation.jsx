import { ShieldAlert } from "lucide-react";

const RISK_COLORS = {
  "Very Low": "#10b981", "Low": "#3b82f6",
  "Medium": "#f59e0b", "High": "#f97316", "Very High": "#ef4444",
};

export default function RiskExplanation({ text, probabilities }) {
  return (
    <div style={card}>
      <div style={header}>
        <div style={iconBox}><ShieldAlert size={16} color="#8b5cf6" /></div>
        <span style={title}>Risk Explanation</span>
      </div>
      <p style={body}>{text || "Loading..."}</p>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {Object.entries(probabilities || {}).map(([k, v]) => (
          <div key={k}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4, color: "#94a3b8" }}>
              <span>{k}</span>
              <span style={{ color: RISK_COLORS[k], fontWeight: 600 }}>{(v * 100).toFixed(1)}%</span>
            </div>
            <div style={{ height: 6, background: "rgba(15,23,42,0.6)", borderRadius: 3, overflow: "hidden" }}>
              <div style={{
                height: "100%",
                width: `${v * 100}%`,
                background: `linear-gradient(90deg, ${RISK_COLORS[k]}80, ${RISK_COLORS[k]})`,
                borderRadius: 3,
                transition: "width 0.8s ease",
              }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const card = {
  background: "rgba(30,41,59,0.8)",
  border: "1px solid rgba(139,92,246,0.2)",
  borderRadius: 14, padding: 20,
  backdropFilter: "blur(8px)",
};
const header = { display: "flex", alignItems: "center", gap: 10, marginBottom: 14 };
const iconBox = { background: "#8b5cf620", borderRadius: 8, padding: 7, display: "flex" };
const title   = { fontWeight: 700, fontSize: 14, color: "#e2e8f0" };
const body    = { fontSize: 13, color: "#94a3b8", lineHeight: 1.7, margin: "0 0 14px" };