import { TrendingUp, TrendingDown, Activity } from "lucide-react";

export default function MarketSummary({ text, features }) {
  const roi = features?.roi ?? 0;
  const pos = roi >= 0;
  return (
    <div style={card}>
      <div style={header}>
        <div style={iconBox("#10b981")}><Activity size={16} color="#10b981" /></div>
        <span style={title}>Market Summary</span>
      </div>
      <p style={body}>{text || "Loading..."}</p>
      <div style={statsRow}>
        <Stat label="ROI"        value={`${roi.toFixed(2)}%`}             color={pos ? "#10b981" : "#ef4444"} />
        <Stat label="Volatility" value={`${features?.volatility?.toFixed(2)}%`} color="#f59e0b" />
        <Stat label="RSI"        value={features?.rsi?.toFixed(1)}              color="#6366f1" />
      </div>
    </div>
  );
}

function Stat({ label, value, color }) {
  return (
    <div style={{ textAlign: "center", flex: 1 }}>
      <div style={{ fontSize: 16, fontWeight: 700, color }}>{value}</div>
      <div style={{ fontSize: 11, color: "#64748b", marginTop: 2 }}>{label}</div>
    </div>
  );
}

const card = {
  background: "rgba(30,41,59,0.8)",
  border: "1px solid rgba(16,185,129,0.2)",
  borderRadius: 14, padding: 20,
  backdropFilter: "blur(8px)",
};
const header = { display: "flex", alignItems: "center", gap: 10, marginBottom: 14 };
const iconBox = (color) => ({
  background: `${color}20`, borderRadius: 8,
  padding: 7, display: "flex",
});
const title  = { fontWeight: 700, fontSize: 14, color: "#e2e8f0" };
const body   = { fontSize: 13, color: "#94a3b8", lineHeight: 1.7, margin: "0 0 16px" };
const statsRow = { display: "flex", borderTop: "1px solid rgba(99,102,241,0.1)", paddingTop: 14, gap: 8 };