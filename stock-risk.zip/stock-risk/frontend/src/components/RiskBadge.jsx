const CONFIG = {
  "Very Low":  { bg: "rgba(16,185,129,0.15)", border: "rgba(16,185,129,0.4)",  color: "#6ee7b7", glow: "#10b981" },
  "Low":       { bg: "rgba(59,130,246,0.15)", border: "rgba(59,130,246,0.4)",  color: "#93c5fd", glow: "#3b82f6" },
  "Medium":    { bg: "rgba(245,158,11,0.15)", border: "rgba(245,158,11,0.4)",  color: "#fcd34d", glow: "#f59e0b" },
  "High":      { bg: "rgba(249,115,22,0.15)", border: "rgba(249,115,22,0.4)",  color: "#fdba74", glow: "#f97316" },
  "Very High": { bg: "rgba(239,68,68,0.15)",  border: "rgba(239,68,68,0.4)",   color: "#fca5a5", glow: "#ef4444" },
};

const ICONS = {
  "Very Low": "🛡️", "Low": "✅", "Medium": "⚖️", "High": "⚠️", "Very High": "🔥"
};

export default function RiskBadge({ label, confidence }) {
  const c = CONFIG[label] || CONFIG["Medium"];
  return (
    <div style={{
      background: c.bg,
      border: `2px solid ${c.border}`,
      borderRadius: 14,
      padding: "16px 24px",
      textAlign: "center",
      minWidth: 160,
      boxShadow: `0 0 20px ${c.glow}30`,
    }}>
      <div style={{ fontSize: 28, marginBottom: 6 }}>{ICONS[label]}</div>
      <div style={{ color: c.color, fontWeight: 800, fontSize: 18, letterSpacing: "0.02em" }}>
        {label}
      </div>
      <div style={{ color: "#94a3b8", fontSize: 11, marginTop: 2 }}>RISK LEVEL</div>
      <div style={{
        marginTop: 8,
        background: "rgba(15,23,42,0.5)",
        borderRadius: 6, padding: "4px 10px",
        fontSize: 13, color: c.color, fontWeight: 600,
      }}>
        {(confidence * 100).toFixed(1)}% confidence
      </div>
    </div>
  );
}