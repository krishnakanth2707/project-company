import { useState, useEffect } from "react";
import { getStocks, getPeriods, analyzeStock, getDatasetUrl } from "./api";
import { TrendingUp, TrendingDown, Download, BarChart2, RefreshCw } from "lucide-react";
import RiskBadge from "./components/RiskBadge";
import MarketSummary from "./components/MarketSummary";
import RiskExplanation from "./components/RiskExplanation";
import InvestmentOutlook from "./components/InvestmentOutlook";
import StockCharts from "./components/StockCharts";

export default function App() {
  const [stocks,  setStocks]  = useState([]);
  const [periods, setPeriods] = useState([]);
  const [ticker,  setTicker]  = useState("");
  const [period,  setPeriod]  = useState("1Y");
  const [result,  setResult]  = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    Promise.all([getStocks(), getPeriods()]).then(([s, p]) => {
      setStocks(s);
      setPeriods(p);
      setTicker(s[0]?.ticker || "");
      setMounted(true);
    });
  }, []);

  const handleAnalyze = async () => {
    if (!ticker || !period) return;
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const data = await analyzeStock(ticker, period);
      setResult(data);
    } catch (e) {
      setError(e.response?.data?.detail || "Analysis failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const roi = result?.features?.roi ?? 0;
  const isPositive = roi >= 0;

  return (
    <div style={styles.page}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerInner}>
          <div style={styles.logoRow}>
            <div style={styles.logoIcon}>
              <BarChart2 size={28} color="#fff" />
            </div>
            <div>
              <div style={styles.logoTitle}>StockRisk AI</div>
              <div style={styles.logoSub}>Indian NSE Market · AI-Powered Risk Analysis</div>
            </div>
          </div>
          <a href={getDatasetUrl()} download style={styles.dlBtn}>
            <Download size={15} />
            Download Training Dataset
          </a>
        </div>
      </div>

      <div style={styles.container}>
        {/* Hero */}
        <div style={styles.hero}>
          <div style={styles.heroTitle}>Analyse NSE Stock Risk with AI</div>
          <div style={styles.heroSub}>
            Select any NSE-listed stock and time period. Our Random Forest model trained on
            real Indian market data will assess risk and generate an LLM-powered investment analysis.
          </div>
        </div>

        {/* Control Card */}
        <div style={styles.card}>
          <div style={styles.controlGrid}>
            {/* Stock Dropdown */}
            <div style={styles.fieldGroup}>
              <label style={styles.label}>Select Stock</label>
              <select
                value={ticker}
                onChange={e => setTicker(e.target.value)}
                style={styles.select}
              >
                {stocks.map(s => (
                  <option key={s.ticker} value={s.ticker}>
                    {s.name} ({s.ticker})
                  </option>
                ))}
              </select>
            </div>

            {/* Period Dropdown */}
            <div style={styles.fieldGroup}>
              <label style={styles.label}>Time Period</label>
              <select
                value={period}
                onChange={e => setPeriod(e.target.value)}
                style={styles.select}
              >
                {periods.map(p => (
                  <option key={p.value} value={p.value}>{p.label}</option>
                ))}
              </select>
            </div>

            {/* Analyze Button */}
            <div style={{ ...styles.fieldGroup, justifyContent: "flex-end" }}>
              <label style={{ ...styles.label, opacity: 0 }}>Action</label>
              <button
                onClick={handleAnalyze}
                disabled={loading || !mounted}
                style={{
                  ...styles.analyzeBtn,
                  opacity: loading || !mounted ? 0.7 : 1,
                  cursor: loading || !mounted ? "not-allowed" : "pointer",
                }}
              >
                {loading
                  ? <><RefreshCw size={16} style={styles.spin} /> Analysing...</>
                  : <><TrendingUp size={16} /> Analyse Risk</>
                }
              </button>
            </div>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div style={styles.errorBox}>
            <span style={{ fontWeight: 600 }}>Error: </span>{error}
          </div>
        )}

        {/* Loading skeleton */}
        {loading && (
          <div style={styles.card}>
            <div style={styles.skeletonRow}>
              {[1,2,3].map(i => (
                <div key={i} style={styles.skeletonCard}>
                  <div style={styles.skeletonLine} />
                  <div style={{ ...styles.skeletonLine, width: "70%", marginTop: 10 }} />
                  <div style={{ ...styles.skeletonLine, width: "50%", marginTop: 10 }} />
                </div>
              ))}
            </div>
            <div style={{ textAlign: "center", color: "#64748b", marginTop: 16, fontSize: 14 }}>
              Fetching live NSE data and running AI analysis...
            </div>
          </div>
        )}

        {/* Results */}
        {result && !loading && (
          <>
            {/* Stock Header */}
            <div style={styles.resultHeader}>
              <div style={styles.stockInfo}>
                <div style={styles.stockName}>{result.company}</div>
                <div style={styles.stockMeta}>
                  <span style={styles.tickerBadge}>{result.ticker}</span>
                  <span style={styles.periodBadge}>{result.period}</span>
                  <span style={{
                    ...styles.roiBadge,
                    background: isPositive ? "#dcfce7" : "#fee2e2",
                    color: isPositive ? "#166534" : "#991b1b",
                  }}>
                    {isPositive
                      ? <TrendingUp size={13} />
                      : <TrendingDown size={13} />
                    }
                    ROI: {roi.toFixed(2)}%
                  </span>
                </div>
              </div>
              <RiskBadge
                label={result.prediction.risk_label}
                confidence={result.prediction.confidence}
              />
            </div>

            {/* Key Metrics Strip */}
            <div style={styles.metricsStrip}>
              {[
                { label: "Current Price", value: `₹${result.features.current_price?.toFixed(2)}` },
                { label: "Volatility",    value: `${result.features.volatility?.toFixed(2)}%` },
                { label: "RSI",           value: result.features.rsi?.toFixed(1) },
                { label: "Sharpe Ratio",  value: result.features.sharpe?.toFixed(2) },
                { label: "Max Drawdown",  value: `${result.features.max_drawdown?.toFixed(2)}%` },
                { label: "MA50 Diff",     value: `${result.features.price_vs_ma50?.toFixed(2)}%` },
              ].map(m => (
                <div key={m.label} style={styles.metricCard}>
                  <div style={styles.metricValue}>{m.value}</div>
                  <div style={styles.metricLabel}>{m.label}</div>
                </div>
              ))}
            </div>

            {/* Analysis Cards */}
            <div style={styles.analysisGrid}>
              <MarketSummary
                text={result.llm.market_summary}
                features={result.features}
              />
              <RiskExplanation
                text={result.llm.risk_explanation}
                probabilities={result.prediction.probabilities}
              />
              <InvestmentOutlook
                text={result.llm.investment_outlook}
                headlines={result.headlines}
              />
            </div>

            {/* Charts */}
            <StockCharts
              data={result.chart_data}
              ticker={result.ticker}
              probabilities={result.prediction.probabilities}
            />
          </>
        )}

        {/* Empty state */}
        {!result && !loading && !error && mounted && (
          <div style={styles.emptyState}>
            <div style={styles.emptyIcon}><BarChart2 size={48} color="#cbd5e1" /></div>
            <div style={styles.emptyTitle}>Select a stock and click Analyse Risk</div>
            <div style={styles.emptyText}>
              Choose any NSE-listed Indian stock from the dropdown above to get
              an AI-powered risk assessment with live market data.
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div style={styles.footer}>
        StockRisk AI · NSE India · Powered by Random Forest + LLM · For educational purposes only
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%)",
    fontFamily: "'Inter', 'Segoe UI', system-ui, sans-serif",
    color: "#e2e8f0",
  },
  header: {
    background: "rgba(15,23,42,0.95)",
    borderBottom: "1px solid rgba(99,102,241,0.3)",
    backdropFilter: "blur(12px)",
    position: "sticky", top: 0, zIndex: 100,
    padding: "0 24px",
  },
  headerInner: {
    maxWidth: 1200, margin: "0 auto",
    display: "flex", alignItems: "center",
    justifyContent: "space-between",
    padding: "14px 0",
  },
  logoRow: { display: "flex", alignItems: "center", gap: 14 },
  logoIcon: {
    background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
    borderRadius: 12, padding: 10,
    display: "flex", alignItems: "center", justifyContent: "center",
  },
  logoTitle: { fontSize: 20, fontWeight: 700, color: "#f1f5f9" },
  logoSub:   { fontSize: 12, color: "#94a3b8", marginTop: 2 },
  dlBtn: {
    display: "flex", alignItems: "center", gap: 7,
    background: "rgba(99,102,241,0.15)",
    border: "1px solid rgba(99,102,241,0.4)",
    color: "#a5b4fc", borderRadius: 8,
    padding: "8px 16px", fontSize: 13,
    textDecoration: "none", fontWeight: 500,
    transition: "all 0.2s",
  },
  container: { maxWidth: 1200, margin: "0 auto", padding: "32px 24px" },
  hero: { textAlign: "center", marginBottom: 32 },
  heroTitle: {
    fontSize: 36, fontWeight: 800,
    background: "linear-gradient(135deg, #e2e8f0, #a5b4fc)",
    WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
    marginBottom: 12,
  },
  heroSub: { fontSize: 15, color: "#94a3b8", maxWidth: 620, margin: "0 auto", lineHeight: 1.7 },
  card: {
    background: "rgba(30,41,59,0.8)",
    border: "1px solid rgba(99,102,241,0.2)",
    borderRadius: 16, padding: 24,
    backdropFilter: "blur(8px)",
    marginBottom: 20,
  },
  controlGrid: {
    display: "grid",
    gridTemplateColumns: "2fr 1fr 1fr",
    gap: 20, alignItems: "end",
  },
  fieldGroup: { display: "flex", flexDirection: "column", gap: 8 },
  label: { fontSize: 13, fontWeight: 600, color: "#94a3b8", letterSpacing: "0.05em" },
  select: {
    background: "rgba(15,23,42,0.8)",
    border: "1px solid rgba(99,102,241,0.3)",
    borderRadius: 10, color: "#e2e8f0",
    padding: "12px 16px", fontSize: 14,
    outline: "none", cursor: "pointer",
    width: "100%",
  },
  analyzeBtn: {
    display: "flex", alignItems: "center", justifyContent: "center",
    gap: 8, padding: "12px 24px",
    background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
    border: "none", borderRadius: 10,
    color: "#fff", fontWeight: 700, fontSize: 15,
    width: "100%",
    boxShadow: "0 4px 15px rgba(99,102,241,0.4)",
    transition: "all 0.2s",
  },
  spin: { animation: "spin 1s linear infinite" },
  errorBox: {
    background: "rgba(239,68,68,0.15)",
    border: "1px solid rgba(239,68,68,0.4)",
    borderRadius: 10, padding: "14px 18px",
    color: "#fca5a5", fontSize: 14, marginBottom: 20,
  },
  skeletonRow: { display: "flex", gap: 16 },
  skeletonCard: {
    flex: 1, background: "rgba(15,23,42,0.5)",
    borderRadius: 12, padding: 20,
  },
  skeletonLine: {
    height: 14, borderRadius: 6,
    background: "linear-gradient(90deg, rgba(99,102,241,0.1), rgba(99,102,241,0.2), rgba(99,102,241,0.1))",
    animation: "pulse 1.5s ease-in-out infinite",
    width: "100%",
  },
  resultHeader: {
    display: "flex", alignItems: "flex-start",
    justifyContent: "space-between",
    background: "rgba(30,41,59,0.8)",
    border: "1px solid rgba(99,102,241,0.2)",
    borderRadius: 16, padding: "20px 24px",
    marginBottom: 16, backdropFilter: "blur(8px)",
  },
  stockInfo: {},
  stockName: { fontSize: 24, fontWeight: 700, color: "#f1f5f9", marginBottom: 8 },
  stockMeta: { display: "flex", gap: 10, flexWrap: "wrap" },
  tickerBadge: {
    background: "rgba(99,102,241,0.2)", border: "1px solid rgba(99,102,241,0.4)",
    color: "#a5b4fc", borderRadius: 6, padding: "3px 10px", fontSize: 13, fontWeight: 600,
  },
  periodBadge: {
    background: "rgba(16,185,129,0.15)", border: "1px solid rgba(16,185,129,0.3)",
    color: "#6ee7b7", borderRadius: 6, padding: "3px 10px", fontSize: 13,
  },
  roiBadge: {
    display: "flex", alignItems: "center", gap: 4,
    borderRadius: 6, padding: "3px 10px", fontSize: 13, fontWeight: 600,
  },
  metricsStrip: {
    display: "grid", gridTemplateColumns: "repeat(6, 1fr)",
    gap: 12, marginBottom: 20,
  },
  metricCard: {
    background: "rgba(30,41,59,0.8)",
    border: "1px solid rgba(99,102,241,0.15)",
    borderRadius: 12, padding: "16px 12px", textAlign: "center",
  },
  metricValue: { fontSize: 20, fontWeight: 700, color: "#e2e8f0", marginBottom: 4 },
  metricLabel: { fontSize: 11, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em" },
  analysisGrid: {
    display: "grid", gridTemplateColumns: "1fr 1fr 1fr",
    gap: 16, marginBottom: 20,
  },
  emptyState: {
    textAlign: "center", padding: "80px 24px",
    background: "rgba(30,41,59,0.4)",
    borderRadius: 16, border: "1px dashed rgba(99,102,241,0.3)",
  },
  emptyIcon: { marginBottom: 20 },
  emptyTitle: { fontSize: 20, fontWeight: 600, color: "#94a3b8", marginBottom: 10 },
  emptyText:  { fontSize: 14, color: "#64748b", maxWidth: 400, margin: "0 auto", lineHeight: 1.7 },
  footer: {
    textAlign: "center", padding: "20px",
    color: "#475569", fontSize: 12,
    borderTop: "1px solid rgba(99,102,241,0.1)",
    marginTop: 40,
  },
};