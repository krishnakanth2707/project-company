import axios from "axios";
const BASE = "http://localhost:8000";

export const getStocks  = () => axios.get(`${BASE}/stocks`).then(r => r.data.stocks);
export const getPeriods = () => axios.get(`${BASE}/periods`).then(r => r.data.periods);
export const analyzeStock = (ticker, period) =>
  axios.post(`${BASE}/analyze`, { ticker, period }).then(r => r.data);
export const getDatasetUrl = () => `${BASE}/download-dataset`;